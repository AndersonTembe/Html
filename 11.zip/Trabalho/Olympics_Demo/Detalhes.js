var id=location.href.split("/")
var fixid=id[5].split("=")
console.log(fixid[1])




    //--- Internal functions
    function ajaxHelper(uri, method, data) {
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("AJAX Call[" + uri + "] Fail...");
            }
        });
    }

    alert(url)

    ajaxHelper(url, 'GET').done(function (data) {

        
        console.log(data);
       
        //self.SetFavourites();
    });

