// ViewModel KnockOut
// var vm = function () {
//     console.log('ViewModel initiated...');
//     //---Variáveis locais
//     var self = this;
//     self.error = ko.observable('');

//     var query=location.href.split("?")[1].split("=")[1]
//     self.baseUri = "http://192.168.160.58/Olympics/api/Utils/Search?q="+query;

//     self.displayName = 'Pesquisa por tables';

//     self.records = ko.observableArray([]);
   

//     //--- Page Events
//     self.activate = function (id) {
//         console.log('CALL: getGames...');
        
//         hideLoading();
//         ajaxHelper(this.baseUri, 'GET').done(function (data) {
//             hideLoading();
            
    
//             self.records(data);
        
//         });

        
//     };

//     //--- Internal functions
//     function ajaxHelper(uri, method, data) {
//         self.error(''); // Clear error message
//         return $.ajax({
//             type: method,
//             url: uri,
//             dataType: 'json',
//             contentType: 'application/json',
//             data: data ? JSON.stringify(data) : null,
//             error: function (jqXHR, textStatus, errorThrown) {
//                 console.log("AJAX Call[" + uri + "] Fail...");
//                 hideLoading();
//                 self.error(errorThrown);
//             }
//         });
//     }

//     function sleep(milliseconds) {
//         const start = Date.now();
//         while (Date.now() - start < milliseconds);
//     }

//     function showLoading() {
//         $("#myModal").modal('show', {
//             backdrop: 'static',
//             keyboard: false
//         });
//     }
//     function hideLoading() {
//         $('#myModal').on('shown.bs.modal', function (e) {
//             $("#myModal").modal('hide');
//         })
//     }
//     function getUrlParameter(sParam) {
//         var sPageURL = window.location.search.substring(1),
//             sURLVariables = sPageURL.split('&'),
//             sParameterName,
//             i;
//         console.log("sPageURL=", sPageURL);
//         for (i = 0; i < sURLVariables.length; i++) {
//             sParameterName = sURLVariables[i].split('=');

//             if (sParameterName[0] === sParam) {
//                 return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
//             }
//         }
//     };


//     //--- start ....
//     showLoading();
//     var pg = getUrlParameter('page');
//     console.log(pg);
//     if (pg == undefined)
//         self.activate(1);
//     else {
//         self.activate(pg);
//     }
//     console.log("VM initialized!");
// };

// $(document).ready(function () {
//     console.log("ready!");
//    ko.applyBindings(new vm());
// });

// $(document).ajaxComplete(function (event, xhr, options) {
//     $("#myModal").modal('hide');
// })

// // cor para o button
// function test(){

//     var obj=document.getElementById('innerSearchValue').value // get the query 
//     location.href="./index.html?query="+obj // go to the another page to avoid ko multiple element bidding error
// }

// function goTO(id){

//     location.href="./Detalhes.html?id="+id
// }



// function myfunc(id){

//     document.getElementById(id).style.color="red"

//     let type=null


//     if(location.href.includes("searchAll") || location.href.includes("query")){

//         type="searchAll"
//     }else
//         //type="countries"


//         /// precisa continuar
//     localStorage.setItem(type,id)

//     console.log(localStorage)
// }




class F1AjaxFetchList
{
    favs = null;
    vm = null;
    component = null;

    urlBase = "http://192.168.160.58/Olympics/api/Utils/Search?q="
    urlComponent = null;

    vm = null;
    fetchDoneCallback = null;
    fetchErrorCallback = null;

    static DEFAULT_PAGE_SIZE = 20;
    static PAGE_SIZE_USER = 0;
    static PAGE_SIZE_DISABLE = -1;
    usePaging = true;
    pageCurrent = 1;
    pageSize = window.localStorage.getItem("f1_page_size");
    pageServerSide = false;

    sortField = null;
    sortReverse = false;
    sortServerSide = false;

    lastFetchDataCache = null;
    lastSortedDataCache = null;
    lastCustomQuery = null;
    static lastFetchError = null;

    constructor (component,
        paging_is_server_side = false, page_size = F1AjaxFetchList.PAGE_SIZE_USER,
        sort_field = null, sort_reverse = false, sort_server_side = null)
    {
        this.setComponent(component);
        this.setPaging(page_size, paging_is_server_side);
        this.setSort(sort_field, sort_reverse);
    }

    clearCache()
    {
        this.lastFetchDataCache = null;
        this.lastSortedDataCache = null;
    }

    setComponent(c)
    {
        this.clearCache();

        this.component = c;
        this.urlComponent = this.urlBase.concat(c);

        if (!this.urlComponent.endsWith('/'))
            this.urlComponent = this.urlComponent.concat('/');
    }

    setCallbacks(vm, success, error) {
        this.vm = vm;
        this.fetchDoneCallback = success;
        this.fetchErrorCallback = error;
    }

    setPaging(page_size, server_side)
    {
        this.clearCache();

        if (page_size == F1AjaxFetchList.PAGE_SIZE_USER) {
            if (this.pageSize === null || this.pageSize < 0)
                this.pageSize = F1AjaxFetchList.DEFAULT_PAGE_SIZE;
        } else if (page_size == F1AjaxFetchList.PAGE_SIZE_DISABLE)
                this.usePaging = false;
            else
                this.pageSize = page_size;
        
        this.pageServerSide = server_side; 
    }

    setPage(page)
    {
        this.pageCurrent = page;
    }

    setFavs(b)
    {
        if (b)
            this.favs = new Favs();
        else
            this.favs = null;
    }

    setSort(field, reverse, server_side)
    {
        this.clearCache();

        this.sortField = field;
        this.sortReverse = reverse;
        this.sortServerSide = server_side;
    }

    fetchData(custom_params = null, page = this.pageCurrent)
    {
        var url = this.urlComponent.concat('?');
        if (custom_params)
            for (const [p, v] of custom_params)
                url = url.concat(`&${p}=${v}`);
        
            if (custom_params != this.lastCustomQuery)
                this.clearCache();

        var local_sorting = (this.sortField && !this.sortServerSide) ? {field: this.sortField, reverse: this.sortReverse} : null;
        var server_paging = (this.usePaging && this.pageServerSide && !local_sorting);
        var local_paging = (this.usePaging && !server_paging) ? {size: this.pageSize, current: page} : null;
        var F1Fetcher_self = this;

        if (local_paging || (!server_paging && local_sorting)) {
            if (this.lastFetchDataCache) {
                F1AjaxFetchList.processData(F1Fetcher_self, local_paging, local_sorting, this.lastFetchDataCache);
                return;
            } else {
                console.log("fetchData (local):", url);
                F1AjaxFetchList.ajaxHelper(url, 'GET').done(function (data) {
                    F1Fetcher_self.lastFetchDataCache = [...data.List];
                    F1AjaxFetchList.processData(F1Fetcher_self, local_paging, local_sorting, data.List);
                });
            }
         } else {
            if (this.usePaging && this.pageServerSide)
                    url = url.concat(`&page=${page}&pagesize=${this.pageSize}`);
            
            if (this.sortField && this.sortServerSide)
                    url = url.concat(`&sortfield=${this.sortField}`);

            console.log("fetchData (server-side):", url);
            F1AjaxFetchList.ajaxHelper(url, 'GET').done(function (data) {
                F1Fetcher_self.fetchDoneCallback(F1Fetcher_self.vm, data);
            });
         }
    }

    static processData(self, local_paging, local_sorting, work)
    {
        var data = {};

        if (local_sorting != null) {
            if (self.lastSort != local_sorting) {
                work = work.sort((a, b) => {
                    var x = a[local_sorting.field], y = b[local_sorting.field];
                    if (typeof(x) == typeof(y))
                        switch (typeof(x)) {
                            default:
                            case ("string"):
                                return (!local_sorting.reverse) ? x.localeCompare(y) : y.localeCompare(x);
                            case ("number"):
                                return (!local_sorting.reverse) ? x - y : -x + y;
                        }
                    else {
                        console.warn("local_sorting: type mismatch!");
                        return (!local_sorting.reverse) ? x - y : -x + y;
                    }
                });
                self.lastSort = local_sorting;
                self.lastSortedCache = work;
            } else {
                work = self.lastSortedCache;
            }
        }
        
        if (local_paging) {
            var total_pages = Math.ceil(work.length / local_paging.size);
            var total_items = work.length;
            work = work.slice((local_paging.current - 1) * local_paging.size, (local_paging.current * local_paging.size));
        
            data.CurrentPage = local_paging.current;
            data.PageSize = local_paging.size;
            data.PageCount = total_pages;
            data.HasNext = (local_paging.current < total_pages);
            data.HasPrevious = (local_paging.current > 1);
        } else {
            data.CurrentPage = 1;
            data.PageSize = 9999;
            data.PageCount = 1;
            data.HasNext = false;
            data.HasPrevious = false;
        }

        data.List = work;
        data.Total = total_items;

        console.log("processData finished:", data);
        self.fetchDoneCallback(self.vm, data);
    }
    
    static ajaxHelper(uri, method, data) {
        return $.ajax({
            type: method,
            url: uri,
            dataType: 'json',
            contentType: 'application/json',
            data: data ? JSON.stringify(data) : null,
            error: function (jqXHR, textStatus, errorThrown) {
                console.error("AJAX call to", uri, "failed with error", textStatus);
            }
        });
    }
}

class F1SearchFetchList extends F1AjaxFetchList
{
    lastQuery = null;

    constructor (component,
        paging_is_server_side = false, page_size = F1AjaxFetchList.PAGE_SIZE_USER,
        sort_field = null, sort_reverse = false, sort_server_side = null)
    {
        super(component, false, page_size, sort_field, sort_reverse, false);
    }

    fetchData(custom_params = null, page = null)
    {
        if (page)
            this.setPage(page);
        
        this.fetchQuery();
    }

    fetchQuery(q = this.lastQuery)
    {
        var url = this.urlComponent.concat(`?q=${q}`);

        var local_sorting = (this.sortField) ? {field: this.sortField, reverse: this.sortReverse} : null;
        var local_paging = (this.usePaging) ? {size: this.pageSize, current: this.pageCurrent} : null;
        var F1SearchFetcher_self = this;

        if (q == this.lastQuery && this.lastSortedDataCache) {
            F1AjaxFetchList.processData(F1SearchFetcher_self, local_paging, local_sorting, this.lastFetchDataCache);
        } else {
            console.log("fetchData (local):", url);
            F1AjaxFetchList.ajaxHelper(url, 'GET').done(function (data) {
                F1SearchFetcher_self.lastFetchDataCache = [...data];
                F1AjaxFetchList.processData(F1SearchFetcher_self, local_paging, local_sorting, data);
            });
        }

        this.lastQuery = q;
    }

    setPaging(page_size, server_side = false)
    {
        if (server_side) console.warn("F1SearchFetchList: Server-side paging is ignored!");
        super.setPaging(page_size, false);
    }

    setSort(field, reverse, server_side)
    {
        if (server_side) console.warn("F1SearchFetchList: Server-side sorting is ignored!");
        super.setSort(field, reverse, false);
    }
}

class F1ListVM {
    static favhive = null;
    static idfield = null;

    fetcher = null;
    favs = new Favs();

    displayName = ko.observable('');
    error = ko.observable('');

    sortField = ko.observable();
    sortReverse = ko.observable(false);

    records = ko.observableArray([]);
    hasRecords = ko.observable(false);
    totalRecords = ko.observable(0);

    currentView = ko.observable("all");
    filterFavs = ko.observable(false);

    currentPage = ko.observable(1);
    pagesize = ko.observable(0);
    totalPages = ko.observable(0);
    hasPrevious = ko.observable(false);
    hasNext = ko.observable(false);

    constructor (name, fetcher, id_field = null, fav_component = null, search_fetcher = null, noautostart = false)
    {
        this.displayName(name);
        this.idfield = id_field;
        this.favhive = fav_component ? fav_component : fetcher.component;
        
        this.fetcher = fetcher;
        this.fetcher.setCallbacks(this, F1ListVM.fetchSuccess, F1ListVM.fetchError);

        if (!search_fetcher)
            search_fetcher = new F1SearchFetchList("Search/".concat(fetcher.component));

        search_fetcher.setCallbacks(this, F1ListVM.fetchSuccess, F1ListVM.fetchError);
        this.searchFetcher = search_fetcher;

        this.pagesize(fetcher.pageSize);

        if (!noautostart)
            this.start();
    }

    swapFetcher(fetcher, clear_callbacks_from_old)
    {
        var old = this.fetcher;
        
        fetcher.setCallbacks(this, F1ListVM.fetchSuccess, F1ListVM.fetchError);
        this.fetcher = fetcher;

        if (clear_callbacks_from_old)
            old.setCallbacks(null, null, null);
        
        return old;
    }

    static fetchSuccess(self, data) {
        data.List.forEach((d) => {
            d.isFavourite = ko.observable(self.favs.get(d.Source.concat("s"), d[self.idfield]));
        });

        self.hasRecords(true);
        self.records(data.List);
        self.allRecords = data.List;
        self.currentPage(data.CurrentPage);
        self.hasNext(data.HasNext);
        self.hasPrevious(data.HasPrevious);
        self.pagesize(data.PageSize)
        self.totalPages(data.PageCount);
        self.totalRecords(data.Total);

        F1ListVM.hideLoading();
    }

    static fetchError(self, text_status, e) {
    }

    activate()
    {
        this.fetcher.fetchData();
    }

    changePage(page)
    {
        unfilterFavs();
        this.setPage(page);
        this.activate();
    }

    setPage(page)
    {
        if (page == undefined) page = 1;
        F1ListVM.setUrlParameter("page", page);
        this.fetcher.setPage(page);
        this.currentPage(page);
    }

    setSort(field, reverse, server_side)
    {
        if (field == undefined) {
            this.sortField();
            this.sortReverse(false);
            return;
        }

        this.fetcher.setSort(field == "id" ? this.idfield : field, reverse, server_side);

        this.sortField(field);
        this.sortReverse(reverse);

        F1ListVM.setUrlParameter("sort", field);
        F1ListVM.setUrlParameter("ord", reverse ? "desc" : "asc");
    }

    changeSort(field, reverse, server_side, internal_field)
    {
        this.setSort(field, reverse, server_side, internal_field)        
        this.activate();
    }

    setPaging(size, server_side)
    {
        this.pagesize(size);
        this.fetcher.setPaging(size, server_side);
    }

    changePaging(size, server_side)
    {
        this.setPaging(size, server_side);
        this.activate();
    }

    setLocalFilterSearch(b, fetcher = null)
    {
        this.clearSearch();

        if (b) {
            if (!this.originalSearchFetcher)
                this.oldsearchFetcher = this.searchFetcher;
            
            if (!fetcher)
                fetcher = new F1LocalFilterFetchList(this.fetcher.component, false, this.pagesize, false, false, false);

            var f = new F1AjaxFetchList(this.fetcher.component, false, 9999, null, false, false);
            f.setCallbacks(this, function (F1FetchHelper_self, data) { 
                F1FetchHelper_self.searchFetcher.setDataCache([...data.List]);
            }, null);
            f.fetchData();

            this.searchFetcher = fetcher;
        } else {
            this.searchFetcher = this.oldsearchFetcher;
        }
    }

    search(q = "", page = 1)
    {
        if (!this.currentView().startsWith("search")) {
            this.old = this.swapFetcher(this.searchFetcher);
        }

        this.currentView("searchAll");

        this.setPaging(this.pagesize(), false);
        this.setSort(this.sortField(), this.sortReverse(), false)
        this.setPage(page);
        this.fetcher.fetchQuery(q);
    }

    clearSearch()
    {
        if (this.currentView().startsWith("search")) {
            this.currentView("all");
            this.swapFetcher(this.old);

            F1ListVM.clearUrlParameter("search");

            this.fetcher.setPaging(this.pagesize(), this.fetcher.pageServerSide);
            this.fetcher.setSort(this.sortField(), this.sortReverse(), false);
            this.fetcher.fetchData();
        }
    }

    start()
    {
        var page = F1ListVM.getUrlParameter("page");
        var sort_field = F1ListVM.getUrlParameter("sort");
        var sort_ord = F1ListVM.getUrlParameter("ord");
        var search = getQueryUrlParameter("search");
    
        if (sort_ord == "asc") sort_ord = false;
        else if (sort_ord == "desc") sort_ord = true;

        this.setSort(sort_field, sort_ord, false, null);

        if (search)
            this.search(search, page);
        else {
            this.setPage(page);
            this.activate();
        }
    }

    previousPage = ko.computed(function () {
        return this.currentPage() * 1 - 1;
    }, this);
    
    nextPage = ko.computed(function () {
        return this.currentPage() * 1 + 1;
    }, this);
    
    fromRecord = ko.computed(function () {
        return this.previousPage() * this.pagesize() + 1;
    }, this);
    
    toRecord = ko.computed(function () {
        return Math.min(this.currentPage() * this.pagesize(), this.totalRecords());
    }, this);
    
    pageArray = function () {
        var list = [];
        var size = Math.min(this.totalPages(), 9);
        var step;
        if (size < 9 || this.currentPage() === 1)
            step = 0;
        else if (this.currentPage() >= this.totalPages() - 4)
            step = this.totalPages() - 9;
        else
            step = Math.max(this.currentPage() - 5, 0);

        for (var i = 1; i <= size; i++)
            list.push(i + step);
        return list;
    };

    addFav(record) {
        var hive = record.Source.concat("s");
        this.favs.add(hive, record[this.idfield]);
        record.isFavourite(true);
    }
    
    removeFav(record) {
        var hive = record.Source.concat("s");
        this.favs.remove(hive, record[this.idfield]);
        record.isFavourite(false);
    }

    autoChangeSort(field) {
        if (vm.sortField() == field)
            this.changeSort(field, !vm.sortReverse());
        else
            this.changeSort(field, vm.sortReverse());
    }

    static showLoading() {
        $("#myModal").modal('show', {
            backdrop: 'static',
            keyboard: false
        });
    }

    static hideLoading() {
        $('#myModal').on('shown.bs.modal', function (e) {
            $("#myModal").modal('hide');
        })
    }

    static sleep(milliseconds) {
        const start = Date.now();
        while (Date.now() - start < milliseconds);
    }

    static getUrlParameter(sParam) {
        var sPageURL = window.location.hash.slice(1),
            sURLVariables = sPageURL.split(';'),
            sParameterName,
            i;
        console.log("sPageURL=", sPageURL);
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }

    };

    static setUrlParameter(sParam, value) {
        var sPageURL = window.location.hash.slice(1),
            iParam = sPageURL.indexOf(sParam),
            iValue = sPageURL.indexOf("=", iParam) + 1,
            iValueEnd = sPageURL.indexOf(";", iValue);
        
        value = encodeURIComponent(value);
        
        if (!sPageURL.length)
            window.location.hash = `${sParam}=${value}`;
        else if (iParam < 0)
            window.location.hash = sPageURL.concat(`;${sParam}=${value}`)
        else if (iValueEnd < 0)
            window.location.hash = sPageURL.slice(0, iValue).concat(value);
        else
            window.location.hash = sPageURL.slice(0, iValue).concat(value).concat(sPageURL.slice(iValueEnd));
    }

    static clearUrlParameter(sParam)
    {
        F1ListVM.setUrlParameter(sParam, "");
    }
}

function filterByFavs()
{
    vm.filterFavs(true);

    var filtered = [];
    vm.records().forEach((l) => {
        if (l.isFavourite())
            filtered.push(l);
    });

    vm.records(filtered);
}

function unfilterFavs()
{
    vm.records(vm.allRecords);
    vm.filterFavs(false);
}

function autoChangeSort(field)
{
    vm.autoChangeSort(field);
}

function filterByFavs()
{
    vm.filterFavs(true);

    var filtered = [];
    vm.records().forEach((l) => {
        if (l.isFavourite())
            filtered.push(l);
    });

    vm.records(filtered);
}

function unfilterFavs()
{
    vm.records(vm.allRecords);
    vm.filterFavs(false);
}

function addFav(record) {
    vm.addFav(record);
}

function removeFav(record) {
    vm.removeFav(record);
}

function changePage(page, immediately = true)
{
    if (immediately)
        vm.changePage(page);
    else
        vm.setPage(page);
}

function changePaging(size, server_side, immediately = true)
{
    if (immediately)
        vm.changePaging(size, server_side);
    else
        vm.setPaging(size, server_side);
}

function autoChangeSort(field)
{
    vm.autoChangeSort(field);
}

function changeSort(field, reverse, apply_immediately = true)
{
    if (apply_immediately)
        vm.changeSort(field, reverse, false);
    else
        vm.setSort(field, reverse, false);
}

function search(q)
{
    vm.search(q);
}

function getQueryUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

var f = new F1AjaxFetchList("");
var sf = new F1SearchFetchList("Search/All");
var vm = new F1ListVM("Search results", f, "Id", null, sf);

ko.applyBindings(vm);